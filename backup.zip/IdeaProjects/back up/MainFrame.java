import javax.swing.*;  // Import all Swing components (JFrame, JPanel, JTabbedPane, etc.)
import java.awt.*;      // Import AWT components (Layout managers, Colors, etc.)

public class MainFrame extends JFrame {
    private JTabbedPane tabbedPane;
    private PaymentPage paymentPage;
    private Customer customer;

    public MainFrame() {
        setTitle("Sports Event Planner");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        customer = new Customer();  // Initialize customer object
        tabbedPane = new JTabbedPane();

        HomePage homePage = new HomePage(this);
        SchedulePage schedulePage = new SchedulePage(this);
        TicketsPage ticketsPage = new TicketsPage(this);
        ParkingPage parkingPage = new ParkingPage(this);
        PlanTripPage planTripPage = new PlanTripPage(this, customer);  // Pass Customer object

        tabbedPane.add("Home", homePage);
        tabbedPane.add("Plan Your Trip", planTripPage);
        tabbedPane.add("Schedule", schedulePage);
        tabbedPane.add("Tickets", ticketsPage);
        tabbedPane.add("Parking", parkingPage);


        add(tabbedPane);
        setVisible(true);
    }

    public void switchToTab(String tabName) {
        int index = tabbedPane.indexOfTab(tabName);
        if (index != -1) {
            tabbedPane.setSelectedIndex(index);
        } else {
            System.err.println("Tab not found: " + tabName);
        }
    }

    public void switchToPaymentPage(Customer customer) {
        int index = tabbedPane.indexOfTab("Payment");

        if (index != -1) {
            // ✅ If Payment tab exists, switch to it instead of creating a new one
            tabbedPane.setSelectedIndex(index);
        } else {
            paymentPage = new PaymentPage(this, customer);
            tabbedPane.add("Payment", paymentPage);
            tabbedPane.setSelectedIndex(tabbedPane.indexOfTab("Payment"));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}
