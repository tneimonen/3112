import javax.swing.*;
import java.awt.*;

public class ParkingPage extends JPanel {
    private MainFrame mainFrame;

    public ParkingPage(MainFrame frame) { // Accept MainFrame as an argument
        this.mainFrame = frame;
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Parking Options", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        JTextArea parkingArea = new JTextArea();
        parkingArea.setText("🚗 VIP Parking - $50 (20 spots left)\n" +
                "🚙 General Parking - $25 (100 spots left)\n" +
                "🅿️ Economy Parking - $10 (200 spots left)");
        parkingArea.setEditable(false);
        add(new JScrollPane(parkingArea), BorderLayout.CENTER);
    }
}
