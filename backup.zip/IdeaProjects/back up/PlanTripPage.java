import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PlanTripPage extends JPanel {
    private MainFrame mainFrame;
    private Customer customer;
    private JComboBox<String> gameDropdown;
    private JComboBox<String> ticketDropdown;
    private JComboBox<String> parkingDropdown;
    private JButton confirmButton, payButton, backButton;
    private JTextArea confirmationArea;

    public PlanTripPage(MainFrame frame, Customer customer) {
        this.mainFrame = frame;
        this.customer = customer;
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Plan Your Trip", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        JPanel selectionPanel = new JPanel(new GridLayout(4, 2, 10, 10));

        String[] games = {
                "Carolina Panthers vs. NY Giants - Feb 20, 2025",
                "Charlotte Hornets vs. Miami Heat - Feb 25, 2025",
                "Charlotte FC vs. Atlanta United - March 10, 2025" };

        String[] tickets = {
                "Lower Deck - $120",
                "Middle Deck - $80",
                "Upper Deck - $50" };
        String[] parking = {
                "VIP Parking - $50",
                "Reserved Park - $35",
                "General Parking - $25",
                "Economy Parking - $10" };

        gameDropdown = new JComboBox<>(games);
        ticketDropdown = new JComboBox<>(tickets);
        parkingDropdown = new JComboBox<>(parking);

        selectionPanel.add(new JLabel("Select Game:"));
        selectionPanel.add(gameDropdown);
        selectionPanel.add(new JLabel("Select Tickets:"));
        selectionPanel.add(ticketDropdown);
        selectionPanel.add(new JLabel("Select Parking:"));
        selectionPanel.add(parkingDropdown);

        confirmButton = new JButton("Confirm Trip");
        payButton = new JButton("Proceed to Payment");
        payButton.setEnabled(false); // Disabled until trip is confirmed

        selectionPanel.add(confirmButton);
        selectionPanel.add(payButton);

        add(selectionPanel, BorderLayout.CENTER);

        confirmationArea = new JTextArea();
        confirmationArea.setEditable(false);
        confirmationArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(new JScrollPane(confirmationArea), BorderLayout.SOUTH);

        backButton = new JButton("Back");
        backButton.addActionListener(e -> frame.switchToTab("Home"));
        add(backButton, BorderLayout.WEST);

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirmTrip();
            }
        });

        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.switchToPaymentPage(customer);
            }
        });
    }

    private void confirmTrip() {
        customer.setSelectedGame((String) gameDropdown.getSelectedItem());
        customer.setSelectedTicket((String) ticketDropdown.getSelectedItem());
        customer.setSelectedParking((String) parkingDropdown.getSelectedItem());

        confirmationArea.setText("✅ Your Trip Plan:\n"
                + "Game: " + customer.getSelectedGame() + "\n"
                + "Tickets: " + customer.getSelectedTicket() + "\n"
                + "Parking: " + customer.getSelectedParking());

        payButton.setEnabled(true);
    }
}
