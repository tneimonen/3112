import javax.swing.*;
import java.awt.*;

public class SchedulePage extends JPanel {
    private MainFrame mainFrame;

    public SchedulePage(MainFrame frame) { // Accept MainFrame as an argument
        this.mainFrame = frame;
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Game Schedule", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        JTextArea scheduleArea = new JTextArea();
        scheduleArea.setText("🏈 Carolina Panthers vs. NY Giants - Feb 20, 2025\n" +
                "🏀 Charlotte Hornets vs. Miami Heat - Feb 25, 2025\n" +
                "⚽ Charlotte FC vs. Atlanta United - March 10, 2025");
        scheduleArea.setEditable(false);
        add(new JScrollPane(scheduleArea), BorderLayout.CENTER);
    }
}
