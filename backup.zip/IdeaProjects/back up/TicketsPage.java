import javax.swing.*;
import java.awt.*;

public class TicketsPage extends JPanel {
    private MainFrame mainFrame;

    public TicketsPage(MainFrame frame) { // Accept MainFrame as an argument
        this.mainFrame = frame;
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Ticket Availability", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        JTextArea ticketsArea = new JTextArea();
        ticketsArea.setText("🎟️ Lower Deck - $120 (50 left)\n" +
                "🎟️ Middle Deck - $80 (100 left)\n" +
                "🎟️ Upper Deck - $50 (200 left)");
        ticketsArea.setEditable(false);
        add(new JScrollPane(ticketsArea), BorderLayout.CENTER);
    }
}
