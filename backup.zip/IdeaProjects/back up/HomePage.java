import javax.swing.*;
import java.awt.*;

public class HomePage extends JPanel {
    public HomePage(MainFrame frame) {
        setLayout(new BorderLayout());

        // Banner/Header
        JLabel banner = new JLabel("Welcome to Charlotte Sport's Event Planner", SwingConstants.CENTER);
        banner.setFont(new Font("Arial", Font.BOLD, 24));
        banner.setForeground(Color.WHITE);
        banner.setOpaque(true);
        banner.setBackground(new Color(0, 102, 204));
        add(banner, BorderLayout.NORTH);

        // Center Panel to Hold Image and Buttons
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        // Load and display an image above the buttons
        ImageIcon imageIcon = new ImageIcon("src/charlotte_skyline.jpg");
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Navigation Bar with Buttons
        JPanel navbar = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        navbar.setBackground(new Color(230, 230, 230));
        navbar.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        JButton homeButton = createLargeButton("Home", frame, "Home");
        JButton scheduleButton = createLargeButton("Schedule", frame, "Schedule");
        JButton ticketsButton = createLargeButton("Tickets", frame, "Tickets");
        JButton parkingButton = createLargeButton("Parking", frame, "Parking");
        JButton planTripButton = createLargeButton("Plan Your Trip", frame, "Plan Your Trip");

        navbar.add(homeButton);
        navbar.add(scheduleButton);
        navbar.add(ticketsButton);
        navbar.add(parkingButton);
        navbar.add(planTripButton);

        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(imageLabel);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(navbar);

        add(centerPanel, BorderLayout.CENTER);

        // Content Area - Featured Section
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        JLabel welcomeText = new JLabel("<html><h2>Plan your next sports event with ease!</h2><p>Check schedules, buy tickets, and find the best parking spots.</p></html>");
        welcomeText.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextArea featuredGames = new JTextArea(" Upcoming Featured Game:\n- Carolina Panthers vs. NY Giants (Feb 20, 2025)\n\n Charlotte FC vs. Atlanta United (March 10, 2025)");
        featuredGames.setEditable(false);
        featuredGames.setBackground(new Color(245, 245, 245));
        featuredGames.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        featuredGames.setFont(new Font("Arial", Font.PLAIN, 14));

        contentPanel.add(welcomeText);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(featuredGames);

        add(contentPanel, BorderLayout.SOUTH);
    }

    private JButton createLargeButton(String text, MainFrame frame, String tabName) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setPreferredSize(new Dimension(160, 40));
        button.addActionListener(e -> frame.switchToTab(tabName));
        return button;
    }
}
