import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PaymentPage extends JPanel {
    private MainFrame mainFrame;
    private Customer customer;
    private JTextField nameField, cardNumberField, expDateField, cvvField;
    private JButton payButton, submitButton;
    private JTextArea receiptArea;

    public PaymentPage(MainFrame frame, Customer customer) {
        this.mainFrame = frame;
        this.customer = customer;

        setLayout(new BorderLayout());

        JLabel title = new JLabel("Payment Information", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));

        formPanel.add(new JLabel("Name on Card:"));
        nameField = new JTextField(15);
        formPanel.add(nameField);

        formPanel.add(new JLabel("Card Number:"));
        cardNumberField = new JTextField(15);
        formPanel.add(cardNumberField);

        formPanel.add(new JLabel("Expiration Date (MM/YY):"));
        expDateField = new JTextField(5);
        formPanel.add(expDateField);

        formPanel.add(new JLabel("CVV:"));
        cvvField = new JTextField(3);
        formPanel.add(cvvField);

        payButton = new JButton("Complete Payment");
        submitButton = new JButton("Submit");
        submitButton.setEnabled(false); // Initially disabled, but visible

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(payButton);
        buttonPanel.add(submitButton);

        // Combine buttons and receipt in a single panel
        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(buttonPanel, BorderLayout.NORTH);

        receiptArea = new JTextArea(6, 20);
        receiptArea.setEditable(false);
        receiptArea.setVisible(false);
        receiptArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        southPanel.add(new JScrollPane(receiptArea), BorderLayout.CENTER);

        add(formPanel, BorderLayout.CENTER);
        add(southPanel, BorderLayout.SOUTH);

        payButton.addActionListener(e -> processPayment());
        submitButton.addActionListener(e -> finalizeBooking());
    }

    private void processPayment() {
        String name = nameField.getText().trim();
        String cardNumber = cardNumberField.getText().trim();
        String expDate = expDateField.getText().trim();
        String cvv = cvvField.getText().trim();

        if (name.isEmpty() || cardNumber.isEmpty() || expDate.isEmpty() || cvv.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!cardNumber.matches("\\d{16}")) {
            JOptionPane.showMessageDialog(this, "Card Number must be 16 digits.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!expDate.matches("(0[1-9]|1[0-2])/[0-9]{2}")) {
            JOptionPane.showMessageDialog(this, "Expiration Date must be MM/YY.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!cvv.matches("\\d{3}")) {
            JOptionPane.showMessageDialog(this, "CVV must be 3 digits.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        receiptArea.setText("✅ Payment Successful!\n"
                + "Name: " + name + "\n"
                + "Card Ending in " + cardNumber.substring(12) + "\n"
                + "Trip Details:\n"
                + "Game: " + customer.getSelectedGame() + "\n"
                + "Tickets: " + customer.getSelectedTicket() + "\n"
                + "Parking: " + customer.getSelectedParking() + "\n\n"
                + "Click 'Submit' to finalize your booking.");

        receiptArea.setVisible(true);
        payButton.setEnabled(false);
        submitButton.setEnabled(true);

        revalidate();
        repaint();
    }

    private void finalizeBooking() {
        JOptionPane.showMessageDialog(this, "🎉 Booking Confirmed!\nThank you for your purchase!", "Success", JOptionPane.INFORMATION_MESSAGE);
        submitButton.setEnabled(false);
    }
}