public class Customer {
    private String selectedGame;
    private String selectedTicket;
    private String selectedParking;

    public Customer() {}

    public void setSelectedGame(String game) { this.selectedGame = game; }
    public void setSelectedTicket(String ticket) { this.selectedTicket = ticket; }
    public void setSelectedParking(String parking) { this.selectedParking = parking; }

    public String getSelectedGame() { return selectedGame; }
    public String getSelectedTicket() { return selectedTicket; }
    public String getSelectedParking() { return selectedParking; }
}
