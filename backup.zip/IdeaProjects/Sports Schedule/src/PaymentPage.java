import javax.swing.*;
import java.awt.*;

public class PaymentPage extends JPanel {
    private MainFrame frame;
    private Order order;

    public PaymentPage(MainFrame frame) {
        this.frame = frame;
        this.order = frame.getCurrentOrder();
        setLayout(new GridLayout(6, 2));

        add(new JLabel("Name:"));
        JTextField nameField = new JTextField();
        add(nameField);

        add(new JLabel("Card Number:"));
        JTextField cardNumberField = new JTextField();
        add(cardNumberField);

        add(new JLabel("Expiration Month (1-12):"));
        JTextField expMonthField = new JTextField();
        add(expMonthField);

        add(new JLabel("Expiration Year (e.g., 2025):"));
        JTextField expYearField = new JTextField();
        add(expYearField);

        add(new JLabel("CVV:"));
        JTextField cvvField = new JTextField();
        add(cvvField);

        JTextArea receiptArea = new JTextArea();
        receiptArea.setEditable(false);
        add(receiptArea);

        JButton submitButton = new JButton("Submit Payment");
        submitButton.addActionListener(e -> {
            try {
                long cardNumber = Long.parseLong(cardNumberField.getText());
                int expMonth = Integer.parseInt(expMonthField.getText());
                int expYear = Integer.parseInt(expYearField.getText());
                int cvv = Integer.parseInt(cvvField.getText());

                Payment payment = new Payment("PAY" + System.currentTimeMillis(), cardNumber, expMonth, expYear, cvv);
                order.processPayment(payment);
                order.updateTotal(); // Ensure the order amount is updated

                receiptArea.setText("Payment Successful!\nOrder ID: " + order.getOrderId() + "\nTotal: $" + order.calculateTotal());
            } catch (NumberFormatException ex) {
                receiptArea.setText("Invalid input! Please enter valid numbers.");
            }
        });

        add(submitButton);
    }
}