import javax.swing.*;
import java.awt.*; // ✅ Import BorderLayout from AWT

public class TicketsPage extends JPanel {
    public TicketsPage() {
        setLayout(new BorderLayout()); // ✅ Now recognized

        JTextArea ticketsArea = new JTextArea();
        ticketsArea.setEditable(false);

        // Populate with Ticket objects
        StringBuilder ticketsText = new StringBuilder();
        ticketsText.append("Available Tickets:\n");

        // ✅ Fix: Use getTotalPrice() instead of getPrice()
        Ticket[] tickets = {
                new Ticket("Lower Deck", 50.0, 100),
                new Ticket("Upper Deck", 30.0, 50)
        };

        for (Ticket ticket : tickets) {
            ticketsText.append(ticket.getTotalPrice()) // ✅ Corrected method call
                    .append(" - ")
                    .append(ticket.getTicketType())
                    .append(" (")
                    .append(ticket.getAvailability())
                    .append(" available)\n");
        }

        ticketsArea.setText(ticketsText.toString());
        add(new JScrollPane(ticketsArea), BorderLayout.CENTER); // ✅ Now works
    }
}
