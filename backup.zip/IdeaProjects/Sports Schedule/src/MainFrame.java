import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private JTabbedPane tabbedPane;
    private Customer customer;
    private Order currentOrder;

    public MainFrame() {
        setTitle("Sports Event Planner");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        tabbedPane = new JTabbedPane();
        customer = new Customer("CUST001", "John Doe");
        currentOrder = null;

        // Initialize pages
        HomePage homePage = new HomePage(this);
        SchedulePage schedulePage = new SchedulePage();
        TicketsPage ticketsPage = new TicketsPage();
        ParkingPage parkingPage = new ParkingPage();
        PlanTripPage planTripPage = new PlanTripPage(this, customer);
        PaymentPage paymentPage = new PaymentPage(this);

        // Add tabs
        tabbedPane.addTab("Home", homePage);
        tabbedPane.addTab("Schedule", schedulePage);
        tabbedPane.addTab("Tickets", ticketsPage);
        tabbedPane.addTab("Parking", parkingPage);
        tabbedPane.addTab("Plan Your Trip", planTripPage);

        add(tabbedPane, BorderLayout.CENTER);
    }

    public void switchToTab(String tabName) {
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            if (tabbedPane.getTitleAt(i).equals(tabName)) {
                tabbedPane.setSelectedIndex(i);
                return;
            }
        }
    }

    public void switchToPaymentPage(Customer customer, Order order) {
        this.currentOrder = order;

        // Remove existing Payment tab if it exists
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            if (tabbedPane.getTitleAt(i).equals("Payment")) {
                tabbedPane.remove(i);
                break;
            }
        }

        PaymentPage paymentPage = new PaymentPage(this);
        tabbedPane.addTab("Payment", paymentPage);
        tabbedPane.setSelectedComponent(paymentPage);
    }
    public Order getCurrentOrder() {
        return currentOrder;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}

