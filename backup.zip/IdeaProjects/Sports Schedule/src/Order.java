import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private String orderId;
    private Date orderDate;
    private double amount;
    private Event event;
    private List<OrderItem> items;
    private Payment payment;

    public Order(String orderId, Event event) {
        this.orderId = orderId;
        this.orderDate = new Date();
        this.amount = 0.0;
        this.event = event;
        this.items = new ArrayList<>();
    }

    public double calculateTotal() {
        double total = 0.0;
        for (OrderItem item : items) {
            total += item.getPrice();
        }
        return total;
    }

    public void updateTotal() {
        this.amount = calculateTotal();
    }

    public void processPayment(Payment payment) {
        this.payment = payment;
        updateTotal(); // Ensure total is updated after payment
    }

    // Getters and setters
    public String getOrderId() { return orderId; }
    public Date getOrderDate() { return orderDate; }
    public double getAmount() { return amount; }
    public Event getEvent() { return event; }
    public List<OrderItem> getItems() { return items; }
    public Payment getPayment() { return payment; }

    public void addItem(OrderItem item) {
        items.add(item);
        updateTotal(); // Ensure total is updated when adding an item
    }
}
