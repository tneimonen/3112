import java.util.Date;

public abstract class Event {
    protected String eventName;
    protected Date eventDate;

    public Event(String eventName, Date eventDate) {
        this.eventName = eventName;
        this.eventDate = eventDate;
    }

    public abstract String getDetails();

    // Getters
    public String getEventName() { return eventName; }
    public Date getEventDate() { return eventDate; }
}