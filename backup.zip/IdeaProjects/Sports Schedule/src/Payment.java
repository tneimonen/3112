import java.time.LocalDate; // ✅ Import modern date API

public class Payment {
    private String paymentId;
    private long cardNumber;
    private int expMonth;
    private int expYear;
    private int cvv;

    public Payment(String paymentId, long cardNumber, int expMonth, int expYear, int cvv) {
        this.paymentId = paymentId;
        this.cardNumber = cardNumber;
        this.expMonth = expMonth;
        this.expYear = expYear;
        this.cvv = cvv;
    }

    public boolean process() {
        // Use LocalDate for modern date handling
        LocalDate today = LocalDate.now();
        int currentYear = today.getYear();
        int currentMonth = today.getMonthValue(); // ✅ No deprecation issues

        return expYear > currentYear || (expYear == currentYear && expMonth >= currentMonth);
    }

    // Getters and setters
    public String getPaymentId() { return paymentId; }
    public long getCardNumber() { return cardNumber; }
    public int getExpMonth() { return expMonth; }
    public int getExpYear() { return expYear; }
    public int getCvv() { return cvv; }
}
