import javax.swing.*;
import java.awt.*; // ✅ Import BorderLayout from AWT

public class SchedulePage extends JPanel {
    public SchedulePage() {
        setLayout(new BorderLayout()); // ✅ Now recognized

        JTextArea scheduleArea = new JTextArea();
        scheduleArea.setEditable(false);

        // Populate with Event objects
        StringBuilder scheduleText = new StringBuilder();
        scheduleText.append("Upcoming Events:\n");
        scheduleText.append(new FootballEvent("Super Bowl", new java.util.Date(), "Patriots", "Eagles").getDetails() + "\n");
        scheduleText.append(new BasketballEvent("NBA Finals", new java.util.Date(), "Lakers", "Celtics").getDetails() + "\n");
        scheduleText.append(new SoccerEvent("World Cup Final", new java.util.Date(), "Brazil", "Germany").getDetails() + "\n");

        scheduleArea.setText(scheduleText.toString());
        add(new JScrollPane(scheduleArea), BorderLayout.CENTER); // ✅ Now works
    }
}
