import javax.swing.*;
import java.awt.*;

public class ParkingPage extends JPanel {
    public ParkingPage() {
        setLayout(new BorderLayout());
        JTextArea parkingArea = new JTextArea();
        parkingArea.setEditable(false);

        // Dynamically generate parking spots
        StringBuilder parkingText = new StringBuilder("Available Parking:\n");
        ParkingSpot[] parkingSpots = {
                new ParkingSpot("VIP Parking", 20.0, 20),
                new ParkingSpot("General Parking", 10.0, 50)
        };

        for (ParkingSpot spot : parkingSpots) {
            parkingText.append(spot.getPrice())
                    .append(" - ")
                    .append(spot.getParkingType())
                    .append(" (")
                    .append(spot.getAvailability())
                    .append(" available)\n");
        }

        parkingArea.setText(parkingText.toString());
        add(new JScrollPane(parkingArea), BorderLayout.CENTER);
    }
}
