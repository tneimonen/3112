public class Ticket {
    private String ticketType;
    private double price;
    private int availability;

    public Ticket(String ticketType, double price, int availability) {
        this.ticketType = ticketType;
        this.price = price;
        this.availability = availability;
    }

    public double getTotalPrice() {
        return price;
    }

    public boolean reduceAvailability(int quantity) {
        if (availability >= quantity) {
            availability -= quantity;
            return true;
        }
        return false; // Not enough tickets available
    }

    // Getters and setters
    public String getTicketType() { return ticketType; }
    public int getAvailability() { return availability; }
    public void setAvailability(int availability) { this.availability = availability; }
}
