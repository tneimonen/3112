public class ParkingSpot {
    private String parkingType;
    private double price;
    private int availability;

    public ParkingSpot(String parkingType, double price, int availability) {
        this.parkingType = parkingType;
        this.price = price;
        this.availability = availability;
    }

    public double getPrice() {
        return price;
    }

    // Getters and setters
    public String getParkingType() { return parkingType; }
    public int getAvailability() { return availability; }
    public void setAvailability(int availability) { this.availability = availability; }
}