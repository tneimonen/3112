public class Customer {
    private String custId;
    private String name;
    private String selectedGame;
    private String selectedTicket;
    private String selectedParking;

    public Customer(String custId, String name) {
        this.custId = custId;
        this.name = name;
    }

    public void placeOrder(Order order) {
        // Logic to associate order with customer (e.g., store in a list)
    }

    public String getInfo() {
        return "Customer ID: " + custId + ", Name: " + name;
    }

    // Existing setters and getters
    public void setSelectedGame(String game) { this.selectedGame = game; }
    public void setSelectedTicket(String ticket) { this.selectedTicket = ticket; }
    public void setSelectedParking(String parking) { this.selectedParking = parking; }
    public String getSelectedGame() { return selectedGame; }
    public String getSelectedTicket() { return selectedTicket; }
    public String getSelectedParking() { return selectedParking; }

    // Getters for custId and name
    public String getCustId() { return custId; }
    public String getName() { return name; }
}