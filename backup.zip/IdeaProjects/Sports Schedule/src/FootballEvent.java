import java.util.Date;

public class FootballEvent extends Event {
    private String team1;
    private String team2;

    public FootballEvent(String eventName, Date eventDate, String team1, String team2) {
        super(eventName, eventDate);
        this.team1 = team1;
        this.team2 = team2;
    }

    @Override
    public String getDetails() {
        return eventName + " - " + team1 + " vs " + team2 + " on " + eventDate;
    }

    // Getters
    public String getTeam1() { return team1; }
    public String getTeam2() { return team2; }
}