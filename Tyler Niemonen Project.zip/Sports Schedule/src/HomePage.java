import javax.swing.*;
import java.awt.*;

public class HomePage extends JPanel {
    public HomePage(MainFrame frame) {
        setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome to Sports Event Planner!");
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        add(welcomeLabel, BorderLayout.CENTER);

        JPanel navPanel = new JPanel();
        JButton scheduleButton = new JButton("Schedule");
        scheduleButton.addActionListener(e -> frame.switchToTab("Schedule"));
        navPanel.add(scheduleButton);

        JButton planTripButton = new JButton("Plan Your Trip");
        planTripButton.addActionListener(e -> frame.switchToTab("Plan Your Trip"));
        navPanel.add(planTripButton);

        add(navPanel, BorderLayout.SOUTH);

        JLabel imageLabel = new JLabel(new ImageIcon("charlotte_skyline.jpg"));
        add(imageLabel, BorderLayout.NORTH);
    }
}