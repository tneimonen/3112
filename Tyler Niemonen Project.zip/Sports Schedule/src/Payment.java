import java.time.LocalDate; //

public class Payment {
    private String paymentId;
    private long cardNumber;
    private int expMonth;
    private int expYear;
    private int cvv;

    public Payment(String paymentId, long cardNumber, int expMonth, int expYear, int cvv) {
        this.paymentId = paymentId;
        this.cardNumber = cardNumber;
        this.expMonth = expMonth;
        this.expYear = expYear;
        this.cvv = cvv;
    }

    public boolean process() {
        LocalDate today = LocalDate.now();
        int currentYear = today.getYear();
        int currentMonth = today.getMonthValue();

        return expYear > currentYear || (expYear == currentYear && expMonth >= currentMonth);
    }

}
