import javax.swing.*;
import java.awt.*;

public class TicketsPage extends JPanel {
    public TicketsPage() {
        setLayout(new BorderLayout());

        JTextArea ticketsArea = new JTextArea();
        ticketsArea.setEditable(false);

        StringBuilder ticketsText = new StringBuilder();
        ticketsText.append("Available Tickets:\n");

        Ticket[] tickets = {
                new Ticket("Box Suite", 200.0, 10),
                new Ticket("Lower Deck", 50.0, 100),
                new Ticket("Upper Deck", 30.0, 50),
                new Ticket("Standing Room Only", 20.0, 200)
        };

        for (Ticket ticket : tickets) {
            ticketsText.append(String.format("$%.2f", ticket.getTotalPrice()))
                    .append(" - ")
                    .append(ticket.getTicketType())
                    .append(" (")
                    .append(ticket.getAvailability())
                    .append(" available)\n");
        }

        ticketsArea.setText(ticketsText.toString());
        add(new JScrollPane(ticketsArea), BorderLayout.CENTER);
    }
}
