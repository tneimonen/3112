import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainFrame extends JFrame {
    private JTabbedPane tabbedPane;
    private Customer customer;
    private Order currentOrder;
    private List<Event> allGames;

    public MainFrame() {
        setTitle("Sports Event Planner");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        allGames = buildAllGames();

        tabbedPane = new JTabbedPane();
        customer = new Customer("CUST001", "John Doe");
        currentOrder = null;

        HomePage homePage = new HomePage(this);
        SchedulePage schedulePage = new SchedulePage(allGames);
        TicketsPage ticketsPage = new TicketsPage();
        ParkingPage parkingPage = new ParkingPage();
        PlanTripPage planTripPage = new PlanTripPage(this, customer, allGames);

        tabbedPane.addTab("Home", homePage);
        tabbedPane.addTab("Schedule", schedulePage);
        tabbedPane.addTab("Tickets", ticketsPage);
        tabbedPane.addTab("Parking", parkingPage);
        tabbedPane.addTab("Plan Your Trip", planTripPage);

        add(tabbedPane, BorderLayout.CENTER);
    }

    private List<Event> buildAllGames() {
        List<Event> games = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();

        games.add(new FootballEvent("Game 1", calendar.getTime(), "Panthers", "Falcons"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 2", calendar.getTime(), "Panthers", "Saints"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 3", calendar.getTime(), "Panthers", "Buccaneers"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 4", calendar.getTime(), "Panthers", "Packers"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 5", calendar.getTime(), "Panthers", "Cowboys"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 6", calendar.getTime(), "Panthers", "Eagles"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 7", calendar.getTime(), "Panthers", "Giants"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 8", calendar.getTime(), "Panthers", "Bears"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 9", calendar.getTime(), "Panthers", "49ers"));
        calendar.add(Calendar.DATE, 3);
        games.add(new FootballEvent("Game 10", calendar.getTime(), "Panthers", "Seahawks"));
        calendar.add(Calendar.DATE, 3);

        games.add(new BasketballEvent("Game 1", calendar.getTime(), "Hornets", "Lakers"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 2", calendar.getTime(), "Hornets", "Celtics"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 3", calendar.getTime(), "Hornets", "Knicks"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 4", calendar.getTime(), "Hornets", "Heat"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 5", calendar.getTime(), "Hornets", "Nets"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 6", calendar.getTime(), "Hornets", "Hawks"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 7", calendar.getTime(), "Hornets", "Bucks"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 8", calendar.getTime(), "Hornets", "Bulls"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 9", calendar.getTime(), "Hornets", "Raptors"));
        calendar.add(Calendar.DATE, 3);
        games.add(new BasketballEvent("Game 10", calendar.getTime(), "Hornets", "76ers"));
        calendar.add(Calendar.DATE, 3);

        games.add(new SoccerEvent("Game 1", calendar.getTime(), "Charlotte FC", "Atlanta United"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 2", calendar.getTime(), "Charlotte FC", "NYCFC"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 3", calendar.getTime(), "Charlotte FC", "Orlando City"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 4", calendar.getTime(), "Charlotte FC", "LA Galaxy"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 5", calendar.getTime(), "Charlotte FC", "Seattle Sounders"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 6", calendar.getTime(), "Charlotte FC", "Columbus Crew"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 7", calendar.getTime(), "Charlotte FC", "Inter Miami"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 8", calendar.getTime(), "Charlotte FC", "D.C. United"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 9", calendar.getTime(), "Charlotte FC", "Austin FC"));
        calendar.add(Calendar.DATE, 3);
        games.add(new SoccerEvent("Game 10", calendar.getTime(), "Charlotte FC", "Toronto FC"));

        return games;
    }

    public void switchToPaymentPage(Customer customer, Order order) {
        this.currentOrder = order;
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            if (tabbedPane.getTitleAt(i).equals("Payment")) {
                tabbedPane.remove(i);
                break;
            }
        }
        PaymentPage paymentPage = new PaymentPage(this);
        tabbedPane.addTab("Payment", paymentPage);
        tabbedPane.setSelectedComponent(paymentPage);
    }

    public void switchToTab(String tabName) {
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            if (tabbedPane.getTitleAt(i).equals(tabName)) {
                tabbedPane.setSelectedIndex(i);
                return;
            }
        }
    }

    public Order getCurrentOrder() {
        return currentOrder;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
