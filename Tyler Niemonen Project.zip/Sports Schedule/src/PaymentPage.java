import javax.swing.*;
import java.awt.*;

public class PaymentPage extends JPanel {
    private MainFrame frame;
    private Order order;

    public PaymentPage(MainFrame frame) {
        this.frame = frame;
        this.order = frame.getCurrentOrder();
        setLayout(new GridLayout(7, 2));

        add(new JLabel("Name (as on card):"));
        JTextField nameField = new JTextField();
        add(nameField);

        add(new JLabel("Card Number (16 digits):"));
        JTextField cardNumberField = new JTextField();
        add(cardNumberField);

        add(new JLabel("Expiration Month (1-12):"));
        JTextField expMonthField = new JTextField();
        add(expMonthField);

        add(new JLabel("Expiration Year (e.g., 2025):"));
        JTextField expYearField = new JTextField();
        add(expYearField);

        add(new JLabel("CVV (3 digits):"));
        JTextField cvvField = new JTextField();
        add(cvvField);

        JTextArea receiptArea = new JTextArea();
        receiptArea.setEditable(false);
        add(receiptArea);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton returnButton = new JButton("Return to Home");
        returnButton.setVisible(false);
        returnButton.addActionListener(e -> frame.switchToTab("Home"));

        JButton submitButton = new JButton("Submit Payment");
        submitButton.addActionListener(e -> {
            String cardText = cardNumberField.getText().trim();
            String monthText = expMonthField.getText().trim();
            String yearText = expYearField.getText().trim();
            String cvvText = cvvField.getText().trim();

            if (!cardText.matches("\\d{16}") || !cvvText.matches("\\d{3}")) {
                receiptArea.setText("Invalid input! Check card number and CVV.");
                return;
            }

            try {
                long cardNumber = Long.parseLong(cardText);
                int expMonth = Integer.parseInt(monthText);
                int expYear = Integer.parseInt(yearText);
                int cvv = Integer.parseInt(cvvText);

                Payment payment = new Payment("PAY" + System.currentTimeMillis(), cardNumber, expMonth, expYear, cvv);
                if (!payment.process()) {
                    receiptArea.setText("Card expired.");
                    return;
                }

                order.processPayment(payment);
                order.updateTotal();

                receiptArea.setText("Payment Successful!\nOrder ID: " + order.getOrderId()
                        + "\nTotal: " + String.format("$%.2f", order.calculateTotal()));
                returnButton.setVisible(true);

            } catch (Exception ex) {
                receiptArea.setText("Invalid input.");
            }
        });

        buttonPanel.add(submitButton);
        buttonPanel.add(returnButton);
        add(buttonPanel);
    }
}
