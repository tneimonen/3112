public class OrderItem {
    private String itemType;
    private int quantity;
    private double price;

    public OrderItem(String itemType, int quantity, double price) {
        this.itemType = itemType;
        this.quantity = quantity;
        this.price = price;
    }

    public double getPrice() {
        return price * quantity;
    }

}