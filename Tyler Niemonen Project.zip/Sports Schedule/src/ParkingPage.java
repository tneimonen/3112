import javax.swing.*;
import java.awt.*;

public class ParkingPage extends JPanel {
    public ParkingPage() {
        setLayout(new BorderLayout());
        JTextArea parkingArea = new JTextArea();
        parkingArea.setEditable(false);

        StringBuilder parkingText = new StringBuilder("Available Parking:\n");
        ParkingSpot[] parkingSpots = {
                new ParkingSpot("VIP Parking", 20.0, 20),
                new ParkingSpot("Covered Parking", 15.0, 30),
                new ParkingSpot("General Parking", 10.0, 50),
                new ParkingSpot("Economy Lot", 5.0, 100)
        };

        for (ParkingSpot spot : parkingSpots) {
            parkingText.append(String.format("$%.2f", spot.getPrice()))
                    .append(" - ")
                    .append(spot.getParkingType())
                    .append(" (")
                    .append(spot.getAvailability())
                    .append(" available)\n");
        }

        parkingArea.setText(parkingText.toString());
        add(new JScrollPane(parkingArea), BorderLayout.CENTER);
    }
}
