import javax.swing.*;
import java.awt.*;
import java.util.List;

public class SchedulePage extends JPanel {
    public SchedulePage(List<Event> allGames) {
        setLayout(new BorderLayout());

        JTextPane schedulePane = new JTextPane();
        schedulePane.setContentType("text/html");
        schedulePane.setEditable(false);

        StringBuilder html = new StringBuilder();
        html.append("<html><body style='font-family:sans-serif;'>");
        html.append("<h3>Upcoming Events:</h3><br>");

        html.append("<b>Football:</b><br>");
        for (Event event : allGames) {
            if (event instanceof FootballEvent) {
                html.append(event.getDetails()).append("<br>");
            }
        }

        html.append("<br><b>Basketball:</b><br>");
        for (Event event : allGames) {
            if (event instanceof BasketballEvent) {
                html.append(event.getDetails()).append("<br>");
            }
        }

        html.append("<br><b>Soccer:</b><br>");
        for (Event event : allGames) {
            if (event instanceof SoccerEvent) {
                html.append(event.getDetails()).append("<br>");
            }
        }

        html.append("</body></html>");
        schedulePane.setText(html.toString());

        add(new JScrollPane(schedulePane), BorderLayout.CENTER);
    }
}
