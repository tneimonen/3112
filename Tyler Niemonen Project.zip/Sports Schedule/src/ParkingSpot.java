public class ParkingSpot {
    private String parkingType;
    private double price;
    private int availability;

    public ParkingSpot(String parkingType, double price, int availability) {
        this.parkingType = parkingType;
        this.price = price;
        this.availability = availability;
    }

    public double getPrice() {
        return price;
    }

    public String getParkingType() { return parkingType; }
    public int getAvailability() { return availability; }


    @Override
    public String toString() {
        if (parkingType == null || parkingType.isEmpty()) {
            return "No Parking";
        }
        return parkingType + " - " + String.format("$%.2f", price);
    }
}
