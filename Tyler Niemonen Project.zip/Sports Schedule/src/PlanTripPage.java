import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PlanTripPage extends JPanel {
    private MainFrame frame;
    private Customer customer;
    private JComboBox<Event> gameCombo;
    private JComboBox<Ticket> ticketCombo;
    private JComboBox<ParkingSpot> parkingCombo;

    public PlanTripPage(MainFrame frame, Customer customer, List<Event> allGames) {
        this.frame = frame;
        this.customer = customer;
        setLayout(new BorderLayout());

        JPanel selectionPanel = new JPanel(new GridLayout(4, 2));
        selectionPanel.add(new JLabel("Select Game:"));

        gameCombo = new JComboBox<>(allGames.toArray(new Event[0]));
        selectionPanel.add(gameCombo);

        selectionPanel.add(new JLabel("Select Ticket:"));
        ticketCombo = new JComboBox<>(new Ticket[]{
                new Ticket("Courtside", 200.0, 10),
                new Ticket("Lower Deck", 50.0, 100),
                new Ticket("Upper Deck", 30.0, 50),
                new Ticket("Standing Room Only", 20.0, 200)
        });
        selectionPanel.add(ticketCombo);

        selectionPanel.add(new JLabel("Select Parking (Optional):"));
        parkingCombo = new JComboBox<>(new ParkingSpot[]{
                new ParkingSpot("VIP Parking", 20.0, 20),
                new ParkingSpot("Covered Parking", 15.0, 30),
                new ParkingSpot("General Parking", 10.0, 50),
                new ParkingSpot("Economy Lot", 5.0, 100),
                new ParkingSpot("", 0.0, 0) // None option
        });
        selectionPanel.add(parkingCombo);

        JButton confirmButton = new JButton("Confirm Trip");
        confirmButton.addActionListener(e -> confirmTrip());
        selectionPanel.add(confirmButton);

        add(selectionPanel, BorderLayout.CENTER);
    }

    private void confirmTrip() {
        Event selectedEvent = (Event) gameCombo.getSelectedItem();
        Ticket selectedTicket = (Ticket) ticketCombo.getSelectedItem();
        ParkingSpot selectedParking = (ParkingSpot) parkingCombo.getSelectedItem();

        Order order = new Order("ORD" + System.currentTimeMillis(), selectedEvent);
        order.addItem(new OrderItem("Ticket", 1, selectedTicket.getTotalPrice()));

        if (selectedParking.getPrice() > 0) {
            order.addItem(new OrderItem("Parking", 1, selectedParking.getPrice()));
        }

        customer.placeOrder(order);
        frame.switchToPaymentPage(customer, order);
    }
}
