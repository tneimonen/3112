/** Customer class is never really used in the project,
 * but its essentially a placeholder for future development
 */
public class Customer {
    private String custId;
    private String name;

    public Customer(String custId, String name) {
        this.custId = custId;
        this.name = name;
    }

    public void placeOrder(Order order) {
    }
}
