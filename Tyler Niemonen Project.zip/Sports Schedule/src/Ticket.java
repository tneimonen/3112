public class Ticket {
    private String ticketType;
    private double price;
    private int availability;

    public Ticket(String ticketType, double price, int availability) {
        this.ticketType = ticketType;
        this.price = price;
        this.availability = availability;
    }

    public double getTotalPrice() {
        return price;
    }

    public String getTicketType() { return ticketType; }
    public int getAvailability() { return availability; }


    @Override
    public String toString() {
        return ticketType + " - " + String.format("$%.2f", price) + " (" + availability + " available)";
    }
}
