import java.util.Date;

public class BasketballEvent extends Event {
    private String team1;
    private String team2;

    public BasketballEvent(String eventName, Date eventDate, String team1, String team2) {
        super(eventName, eventDate);
        this.team1 = team1;
        this.team2 = team2;
    }

    @Override
    public String getDetails() {
        return eventName + " - " + team1 + " vs " + team2 + " on " + eventDate;
    }


    @Override
    public String toString() {
        return getDetails();
    }
}
